package com.projet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ChatFrame extends JFrame {
    private JTextArea chatArea;
    private JTextField messageField;
    private String currentUser;
    private String otherUser;

    public ChatFrame(String user, String other) {
        this.currentUser = user;
        this.otherUser = other;
        
        setTitle("Messagerie - " + currentUser + " avec " + otherUser);
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        chatArea = new JTextArea();
        chatArea.setEditable(false);
        add(new JScrollPane(chatArea), BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        messageField = new JTextField();
        JButton sendButton = new JButton("Envoyer");

        bottomPanel.add(messageField, BorderLayout.CENTER);
        bottomPanel.add(sendButton, BorderLayout.EAST);
        add(bottomPanel, BorderLayout.SOUTH);

        sendButton.addActionListener(e -> sendMessage());
        messageField.addActionListener(e -> sendMessage());

        // Timer pour rafraîchir les messages
        Timer timer = new Timer(2000, e -> loadMessages());
        timer.start();
        
        loadMessages();
    }

    private void sendMessage() {
        String content = messageField.getText().trim();
        if (!content.isEmpty()) {
            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "INSERT INTO messages (expediteur, destinataire, contenu) VALUES (?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, currentUser);
                pstmt.setString(2, otherUser);
                pstmt.setString(3, content);
                pstmt.executeUpdate();
                messageField.setText("");
                loadMessages();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void loadMessages() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT expediteur, contenu, date_envoi FROM messages " +
                         "WHERE (expediteur = ? AND destinataire = ?) OR (expediteur = ? AND destinataire = ?) " +
                         "ORDER BY date_envoi ASC";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, currentUser);
            pstmt.setString(2, otherUser);
            pstmt.setString(3, otherUser);
            pstmt.setString(4, currentUser);
            ResultSet rs = pstmt.executeQuery();

            StringBuilder sb = new StringBuilder();
            while (rs.next()) {
                sb.append("[").append(rs.getString("expediteur")).append("]: ")
                  .append(rs.getString("contenu")).append("\n");
            }
            chatArea.setText(sb.toString());
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
