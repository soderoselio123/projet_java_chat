package com.projet;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class MainFrame extends JFrame {
    private JTextField txtNom, txtPrenom, txtDateNais, txtVille;

    public MainFrame() {
        setTitle("Formulaire d'Inscription et Messagerie");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 2, 10, 10));

        add(new JLabel("Nom:"));
        txtNom = new JTextField();
        add(txtNom);

        add(new JLabel("Prénom:"));
        txtPrenom = new JTextField();
        add(txtPrenom);

        add(new JLabel("Date Naissance (YYYY-MM-DD):"));
        txtDateNais = new JTextField();
        add(txtDateNais);

        add(new JLabel("Ville:"));
        txtVille = new JTextField();
        add(txtVille);

        JButton btnSave = new JButton("Enregistrer");
        add(btnSave);

        JButton btnChat = new JButton("Ouvrir Messagerie");
        add(btnChat);

        btnSave.addActionListener(e -> savePersonne());
        btnChat.addActionListener(e -> openChat());
    }

    private void savePersonne() {
        String nom = txtNom.getText();
        String prenom = txtPrenom.getText();
        String date = txtDateNais.getText();
        String ville = txtVille.getText();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO personne (nom, prenom, date_naissance, ville) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nom);
            pstmt.setString(2, prenom);
            pstmt.setString(3, date);
            pstmt.setString(4, ville);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Données enregistrées avec succès !");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erreur: " + ex.getMessage());
        }
    }

    private void openChat() {
        String user1 = JOptionPane.showInputDialog(this, "Nom de l'utilisateur 1:");
        String user2 = JOptionPane.showInputDialog(this, "Nom de l'utilisateur 2:");
        
        if (user1 != null && user2 != null) {
            new ChatFrame(user1, user2).setVisible(true);
            new ChatFrame(user2, user1).setVisible(true);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
