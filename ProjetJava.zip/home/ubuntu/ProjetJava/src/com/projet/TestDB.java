package com.projet;
import java.sql.*;
public class TestDB {
    public static void main(String[] args) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.println("Connexion réussie !");
            String sql = "INSERT INTO personne (nom, prenom, date_naissance, ville) VALUES ('Test', 'User', '1990-01-01', 'Paris')";
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(sql);
            System.out.println("Insertion réussie !");
            ResultSet rs = stmt.executeQuery("SELECT * FROM personne");
            while(rs.next()) {
                System.out.println("Nom: " + rs.getString("nom"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
